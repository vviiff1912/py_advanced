from project.food import Food


class Fruit(Food):
    def __init__(self, name, expiration_date):
        super().__init__(expiration_date)
        self.name = name


fruit = Fruit('Apple', '02/10/2020')
a = 5
